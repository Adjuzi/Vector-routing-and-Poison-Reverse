#!/usr/bin/env python
import GuiTextArea, RouterPacket, F
from copy import deepcopy


class RouterNode():
    myID = None
    myGUI = None
    sim = None
    costs = None

    # Access simulator variables with:
    # self.sim.POISONREVERSE, self.sim.NUM_NODES, etc.

    # --------------------------------------------------
    def __init__(self, ID, sim, costs):
        self.myID = ID
        self.sim = sim
        self.myGUI = GuiTextArea.GuiTextArea("  Output window for Router #" + str(ID) + "  ")

        self.costs = deepcopy(costs)

        self.distanceVectors = dict()
        self.routes = dict()

        # Create a dict with distance costs and a dict for routes taken
        for i in range(self.sim.NUM_NODES):
            for j in range(self.sim.NUM_NODES):
                if i is j:
                    self.distanceVectors[i, j] = 0
                elif i is self.myID:
                    self.distanceVectors[self.myID, j] = self.costs[j]
                else:
                    self.distanceVectors[i, j] = self.sim.INFINITY
            if self.costs[i] is not self.sim.INFINITY:
                self.routes[i] = i
            else:
                self.routes[i] = -1

        self.printDistanceTable()
        self.prepShareUpdate()

    # --------------------------------------------------
    def recvUpdate(self, pkt):
        for i in range(self.sim.NUM_NODES):
            self.distanceVectors[pkt.sourceid, i] = pkt.mincost[i]

        if self.updateRouter():
            self.prepShareUpdate()

    # --------------------------------------------------
    def sendUpdate(self, pkt):
        self.sim.toLayer2(pkt)

    # --------------------------------------------------
    def printDistanceTable(self):
        self.myGUI.println("Current table for " + str(self.myID) +
                           "  at time " + str(self.sim.getClocktime()))
        self.myGUI.println()

        self.myGUI.println("Our distance vector and routes: ")

        dst = "    dst |"
        divider = "---------"
        for i in range(self.sim.NUM_NODES):
            dst += "    " + str(i)
            divider += "-----"

        self.myGUI.println(dst)
        self.myGUI.println(divider)

        cost_line = " cost   |"
        for i in range(self.sim.NUM_NODES):
            if 9 < self.distanceVectors[self.myID, i] < 100:
                cost_line += "   " + str(self.distanceVectors[self.myID, i])
            elif self.distanceVectors[self.myID, i] > 99:
                cost_line += "  " + str(self.distanceVectors[self.myID, i])
            else:
                cost_line += "    " + str(self.distanceVectors[self.myID, i])
        self.myGUI.println(cost_line)

        route_line = " route  |"
        for i in self.routes:
            if self.routes[i] is not -1:
                route_line += "    " + str(self.routes[i])
            else:
                route_line += "    -"
        self.myGUI.println(route_line)

    # --------------------------------------------------
    def updateLinkCost(self, dest, newcost):
        self.costs[dest] = newcost

        if self.updateRouter():
            self.prepShareUpdate()

    def updateRouter(self):
        updatedTable = False
        for i in range(self.sim.NUM_NODES):
            if i is not self.myID:
                tmpCost = self.costs[i]
                route = i

                for j in range(self.sim.NUM_NODES):
                    if j is not self.myID and self.costs[j] is not self.sim.INFINITY:
                        potentialCost = self.costs[j] + self.distanceVectors[j, i]
                        if potentialCost < tmpCost:
                            tmpCost = potentialCost
                            route = j

                if tmpCost is not self.distanceVectors[self.myID, i]:
                    self.routes[i] = route
                    self.distanceVectors[self.myID, i] = tmpCost
                    updatedTable = True

        return updatedTable

    def prepShareUpdate(self):
        shareList = []
        for i in range(self.sim.NUM_NODES):

            if i is not self.myID and self.costs[i] is not self.sim.INFINITY:

                for j in range(self.sim.NUM_NODES):
                    shareList.append(self.distanceVectors[self.myID, j])
                    # Poison reverse
                    if self.sim.POISONREVERSE:
                        if i is self.routes[j] and i is not j:
                            shareList[j] = self.sim.INFINITY

                self.sendUpdate(RouterPacket.RouterPacket(self.myID, i, shareList))
